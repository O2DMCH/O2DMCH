﻿namespace SFSimulator.Core
{
    public enum TypeMapOption
    {
        None,
        Singleton,
        Self,
    }
}
