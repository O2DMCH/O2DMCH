namespace SFSimulator.Core;

public enum GemType
{
    None,
    Strength,
    Dexterity,
    Intelligence,
    Constitution,
    Luck,
    Black,
    Legendary
}
