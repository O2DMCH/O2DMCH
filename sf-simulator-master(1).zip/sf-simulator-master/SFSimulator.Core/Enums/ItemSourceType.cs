﻿namespace SFSimulator.Core
{
    public enum ItemSourceType
    {
        BeforeQuest,
        AfterQuest,
        Expedition
    }
}
