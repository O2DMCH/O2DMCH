﻿namespace SFSimulator.Core
{
    public enum ActionType
    {
        BuyGriffin,
        BuyTiger,
        SpinMaxTimes,
        SpinOnce,
        DrinkAllBeers,
        DrinkOneBeer,
        UpgradeTreasury,
        UpgradeAcademy,
        UpgradeGoldPit,
        AddOneHydraHead
    }
}
