﻿namespace SFSimulator.Core
{
    public enum QuestPriorityType
    {
        Gold,
        Experience,
        Hybrid
    }
}
