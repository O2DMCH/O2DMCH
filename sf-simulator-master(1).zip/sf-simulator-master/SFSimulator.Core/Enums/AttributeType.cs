namespace SFSimulator.Core;

public enum AttributeType
{
    Strength,
    Dexterity,
    Intelligence,
    Constitution,
    Luck
}
