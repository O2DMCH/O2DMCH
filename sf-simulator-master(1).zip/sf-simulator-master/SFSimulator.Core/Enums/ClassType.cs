﻿namespace SFSimulator.Core
{
    public enum ClassType
    {
        Bert = 0,
        Warrior,
        Mage,
        Scout,
        Assassin,
        BattleMage,
        Berserker,
        DemonHunter,
        Druid,
        Bard,
        Necromancer
    }
}
