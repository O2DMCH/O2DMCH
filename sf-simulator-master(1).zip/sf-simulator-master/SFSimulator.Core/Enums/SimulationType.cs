namespace SFSimulator.Core;

public enum SimulationType
{
    UntilDays = 0,
    UntilLevel = 1,
    UntilBaseStats = 2
}
