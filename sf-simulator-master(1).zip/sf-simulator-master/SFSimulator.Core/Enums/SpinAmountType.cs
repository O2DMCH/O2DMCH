﻿namespace SFSimulator.Core
{
    public enum SpinAmountType
    {
        OnlyFree,
        Max
    }
}
