namespace SFSimulator.Core;

public enum PotionType
{
    None = 0,
    Strength = 1,
    Dexterity = 2,
    Intelligence = 3,
    Constitution = 4,
    Luck = 5,
    Eternity = 6
}
