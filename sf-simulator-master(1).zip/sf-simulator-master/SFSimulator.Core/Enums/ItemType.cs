﻿namespace SFSimulator.Core
{
    public enum ItemType
    {
        None,
        Headgear,
        Breastplate,
        Gloves,
        Boots,
        Weapon,
        Trinket,
        Ring,
        Belt,
        Amulet,
        PetFood
    }
}
