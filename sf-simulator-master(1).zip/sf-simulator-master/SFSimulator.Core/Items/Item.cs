﻿namespace SFSimulator.Core
{
    public class Item
    {
        public ItemType ItemType { get; set; }
        public ItemSourceType ItemSourceType { get; set; }
        public decimal GoldValue { get; set; }
    }
}
