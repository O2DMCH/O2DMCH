﻿namespace SFSimulator.Core
{
    public interface IQuestHelper
    {
        decimal GetTime(int questLength, MountType mountType);
    }
}