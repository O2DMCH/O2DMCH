﻿namespace SFSimulator.Core
{
    public class ScheduleDay
    {
        public List<ActionType> Actions { get; set; } = new ();
        public List<EventType> Events { get; set; } = new ();

    }
}
