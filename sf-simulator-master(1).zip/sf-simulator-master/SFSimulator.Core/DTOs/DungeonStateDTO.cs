﻿namespace SFSimulator.Core;

public class DungeonStateDTO
{

}
