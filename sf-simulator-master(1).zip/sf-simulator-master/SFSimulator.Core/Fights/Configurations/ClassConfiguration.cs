﻿namespace SFSimulator.Core
{
    public sealed class ClassConfiguration
    {
        public double WeaponMultiplier { get; init; }
        public double HealthMultiplier { get; init; }
    }
}
