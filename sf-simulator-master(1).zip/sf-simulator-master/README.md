SF Simulator is a tool for simulating/forecasting base stat and experience gains in a customizable way. 
Most of the gains are calculated via known formulas. Quest and item generator is randomized hence values 
can be offset by a margin.

Simulator does not include:
- Dungeons' Experience
- Legendary Dungeon / Hellevator Gold
- Gold from pet fruits (potion selling)
- Additional events (basic event cycle is implemented)

Note that simulation below level 300 are very unrealiable (base stat cost currently starts at 10mln)

If you found a bug or want to leave a suggestion, you can contact me on discord: abus3r_
