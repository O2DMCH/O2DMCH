export enum QuestPriority {
  Gold = 0,
  Experience = 1,
  Hybrid = 2
}
