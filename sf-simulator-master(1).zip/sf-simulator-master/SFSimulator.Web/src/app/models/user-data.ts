export interface UserData {
  lastSeenPatchNotes?: string | undefined;
  isAdvancedModeEnabled?: boolean | undefined;
};
