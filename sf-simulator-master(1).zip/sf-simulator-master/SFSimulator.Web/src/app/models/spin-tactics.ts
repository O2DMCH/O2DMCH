export enum SpinTactic {
  OnlyFree = 0,
  Max = 1
}
