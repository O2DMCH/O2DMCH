import { WordSpacePipe } from './word-space.pipe';

describe('WordSpacePipe', () => {
  it('create an instance', () => {
    const pipe = new WordSpacePipe();
    expect(pipe).toBeTruthy();
  });
});
