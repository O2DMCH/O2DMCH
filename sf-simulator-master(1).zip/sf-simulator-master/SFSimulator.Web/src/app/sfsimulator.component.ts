import { Component } from '@angular/core';


@Component({
  selector: 'sfsimulator',
  templateUrl: './sfsimulator.component.html',
  styleUrls: ['./sfsimulator.component.scss']
})
export class SFSimulatorComponent {
  constructor() { }
}
