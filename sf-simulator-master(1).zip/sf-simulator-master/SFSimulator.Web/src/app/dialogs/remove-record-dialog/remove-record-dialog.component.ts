import { Component } from '@angular/core';

@Component({
  selector: 'app-remove-record-dialog',
  templateUrl: './remove-record-dialog.component.html',
  styleUrls: ['./remove-record-dialog.component.scss']
})
export class RemoveRecordDialogComponent {

}
