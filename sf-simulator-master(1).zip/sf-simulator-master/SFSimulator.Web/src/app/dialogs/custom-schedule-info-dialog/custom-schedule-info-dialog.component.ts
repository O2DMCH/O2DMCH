import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-schedule-info-dialog',
  templateUrl: './custom-schedule-info-dialog.component.html',
  styleUrls: ['./custom-schedule-info-dialog.component.scss']
})
export class CustomScheduleInfoDialogComponent {

}
