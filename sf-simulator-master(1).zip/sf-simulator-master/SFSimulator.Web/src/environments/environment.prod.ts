export const environment = {
  production: true,
  apiUrl: 'https://sfsimulator.xyz',
  sftoolsLogin: 'https://sftools.mar21.eu/request?scope=default+pets+items+companions&origin=SF%20Simulator',
  currentVersion: '1.9'
};
